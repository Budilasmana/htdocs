<ul class="sidebar transparent2 navbar-nav">

  <li class="nav-item active">
    <a class="nav-link" href="<?php echo site_url('admin/pengguna/index') ?>">
      <i class=" fas fa-users-cog"></i>
      <span>Daftar Pelanggan</span></a>
  </li>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo site_url('admin/kategori/index') ?>">
      <i class="fas fa-cubes"></i>
      <span>Kategori</span></a>
  </li>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo site_url('admin/produk/index') ?>">
      <i class="fas fa-chart-pie"></i>
      <span>Produk</span></a>
  </li>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo site_url('admin/histori/index') ?>">
      <i class="fas fa-chart-bar"></i>
      <span>Riwayat Transaksi</span></a>
  </li>
</ul>