<div>

  <div class=" mt-12 transparent3 static-top">
    <div class="copyright text-center my-auto lobster">
      Copyright © Jamur-Bondowoso Website 2019
    </div>
  </div>
</div>